class BaseFileWriter {
  async writeToFile(fileContent, outputFile) {
    console.log('[WARNING]: Not Implemented!', fileContent);
  }
}

module.exports = BaseFileWriter;
